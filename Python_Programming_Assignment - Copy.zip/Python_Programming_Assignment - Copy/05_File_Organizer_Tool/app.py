
import streamlit as st
from pathlib import Path
import hashlib
import shutil
import json
from datetime import datetime

st.set_page_config(
    page_title="File Organizer Tool",
    page_icon="📁",
    layout="wide"
)

st.title("📁 File Organizer Tool")
st.write("Organize, search for duplicates, rename files and undo changes.")

HISTORY_FILE = Path("organizer_history.json")

CATEGORIES = {
    "Images": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".svg"],
    "Documents": [".pdf", ".doc", ".docx", ".txt", ".ppt", ".pptx",
                  ".xls", ".xlsx", ".csv"],
    "Videos": [".mp4", ".mkv", ".avi", ".mov", ".webm"],
    "Audio": [".mp3", ".wav", ".aac", ".flac", ".ogg"],
    "Code": [".py", ".c", ".cpp", ".java", ".php", ".html", ".css",
             ".js", ".sql"],
    "Archives": [".zip", ".rar", ".7z", ".tar", ".gz"]
}


def load_history():
    if HISTORY_FILE.exists():
        try:
            return json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return []
    return []


def save_history(history):
    HISTORY_FILE.write_text(
        json.dumps(history, indent=2),
        encoding="utf-8"
    )


def get_category(file_path):
    extension = file_path.suffix.lower()

    for category, extensions in CATEGORIES.items():
        if extension in extensions:
            return category

    return "Others"


def unique_path(path):
    """Generate a filename that does not overwrite an existing file."""
    if not path.exists():
        return path

    counter = 1
    while True:
        candidate = path.with_name(
            f"{path.stem}_{counter}{path.suffix}"
        )
        if not candidate.exists():
            return candidate
        counter += 1


def file_hash(file_path):
    digest = hashlib.sha256()

    with file_path.open("rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(chunk)

    return digest.hexdigest()


def get_files(folder):
    return [
        item for item in folder.iterdir()
        if item.is_file()
        and item.name != HISTORY_FILE.name
        and not item.name.startswith(".")
    ]


def record_action(action_type, changes):
    history = load_history()
    history.append({
        "type": action_type,
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "changes": changes
    })
    save_history(history)


def move_backwards(source, destination):
    """Move a file back only if its recorded destination is still valid."""
    source = Path(source)
    destination = Path(destination)

    if source.exists() and not destination.exists():
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(source), str(destination))
        return True

    return False


menu = st.sidebar.radio(
    "Choose Feature",
    [
        "Home",
        "Organize Files",
        "Find Duplicates",
        "Batch Rename",
        "Activity Logs",
        "Undo Last Action"
    ]
)

folder_text = st.sidebar.text_input(
    "Folder Path",
    placeholder=r"C:\Users\YourName\Downloads"
)

if folder_text.strip():
    folder = Path(folder_text.strip().strip('"'))
    if folder.exists() and folder.is_dir():
        st.sidebar.success("Folder found")
    else:
        st.sidebar.warning("Enter a valid folder path.")
else:
    folder = None
    st.sidebar.info("Enter the folder you want to manage.")

st.sidebar.caption(
    "Tip: Test the app with a separate folder containing sample files."
)


if menu == "Home":
    st.subheader("Welcome to File Organizer Tool")

    st.markdown("""
    ### Features
    - **Organize Files:** Move files into folders by file type.
    - **Find Duplicates:** Identify files with identical contents.
    - **Batch Rename:** Rename multiple files using a common prefix.
    - **Activity Logs:** Review changes made by this app.
    - **Undo Last Action:** Reverse the most recent recorded operation.

    ### How to start
    1. Create a test folder on your computer.
    2. Put a few sample files inside it.
    3. Enter its full path in the sidebar.
    4. Select a feature from the sidebar.
    """)

    if folder and folder.is_dir():
        files = get_files(folder)
        col1, col2 = st.columns(2)
        col1.metric("Files in selected folder", len(files))
        col2.metric("Recorded actions", len(load_history()))


elif menu == "Organize Files":
    st.subheader("Organize Files by Category")

    st.write(
        "Files will be moved into Images, Documents, Videos, "
        "Audio, Code, Archives or Others folders."
    )

    st.warning(
        "Only files directly inside the selected folder are organized. "
        "Existing subfolders are not scanned."
    )

    confirm = st.checkbox(
        "I have checked the selected folder and want to organize its files."
    )

    if st.button("Organize Files", type="primary"):
        if not folder or not folder.is_dir():
            st.error("Enter a valid folder path in the sidebar.")
        elif not confirm:
            st.warning("Please confirm before organizing files.")
        else:
            changes = []
            errors = []

            for file_path in get_files(folder):
                try:
                    category = get_category(file_path)
                    destination_folder = folder / category
                    destination_folder.mkdir(exist_ok=True)

                    destination = unique_path(
                        destination_folder / file_path.name
                    )

                    shutil.move(str(file_path), str(destination))
                    changes.append({
                        "from": str(file_path),
                        "to": str(destination)
                    })
                except OSError as error:
                    errors.append(f"{file_path.name}: {error}")

            if changes:
                record_action("Organize Files", changes)
                st.success(f"Successfully organized {len(changes)} file(s).")

            if errors:
                st.error("Some files could not be moved:")
                for error in errors:
                    st.write(error)

            if not changes and not errors:
                st.info("No files found to organize.")

            if changes:
                st.dataframe(changes, use_container_width=True)


elif menu == "Find Duplicates":
    st.subheader("Find Duplicate Files")

    st.write(
        "The tool compares file contents using SHA-256 hashes. "
        "It reports duplicates but does not delete them."
    )

    if st.button("Scan for Duplicates"):
        if not folder or not folder.is_dir():
            st.error("Enter a valid folder path in the sidebar.")
        else:
            files = []

            for current_folder, _, filenames in __import__("os").walk(folder):
                current_path = Path(current_folder)

                if current_path == folder and HISTORY_FILE.name in filenames:
                    filenames.remove(HISTORY_FILE.name)

                for filename in filenames:
                    file_path = current_path / filename

                    if file_path.is_file():
                        files.append(file_path)

            hash_groups = {}
            errors = []

            progress = st.progress(0)

            for index, file_path in enumerate(files):
                try:
                    digest = file_hash(file_path)
                    hash_groups.setdefault(digest, []).append(str(file_path))
                except OSError as error:
                    errors.append(f"{file_path}: {error}")

                progress.progress((index + 1) / max(len(files), 1))

            duplicates = [
                paths for paths in hash_groups.values()
                if len(paths) > 1
            ]

            if duplicates:
                st.warning(f"Found {len(duplicates)} group(s) of duplicate files.")

                for number, group in enumerate(duplicates, start=1):
                    st.write(f"**Duplicate group {number}**")
                    for path in group:
                        st.code(path)
            else:
                st.success("No duplicate files found.")

            if errors:
                st.warning(f"{len(errors)} file(s) could not be checked.")


elif menu == "Batch Rename":
    st.subheader("Batch Rename Files")

    st.write(
        "Give files a common prefix, for example "
        "photo_1.jpg, photo_2.jpg and photo_3.jpg."
    )

    prefix = st.text_input("New filename prefix", value="file")
    start_number = st.number_input(
        "Starting number", min_value=1, value=1, step=1
    )

    if folder and folder.is_dir():
        files = sorted(get_files(folder), key=lambda p: p.name.lower())

        if files:
            st.write("Files that will be renamed:")
            st.dataframe(
                [{"Current name": p.name} for p in files],
                use_container_width=True
            )

            confirm_rename = st.checkbox(
                "I confirm that I want to rename these files."
            )

            if st.button("Rename Files", type="primary"):
                if not prefix.strip():
                    st.error("Enter a filename prefix.")
                elif not confirm_rename:
                    st.warning("Please confirm before renaming.")
                else:
                    changes = []
                    errors = []
                    number = int(start_number)

                    for file_path in files:
                        new_name = f"{prefix.strip()}_{number}{file_path.suffix}"
                        destination = file_path.with_name(new_name)

                        if destination.exists() and destination != file_path:
                            errors.append(
                                f"{new_name} already exists; skipped."
                            )
                            continue

                        try:
                            if destination != file_path:
                                file_path.rename(destination)
                                changes.append({
                                    "from": str(file_path),
                                    "to": str(destination)
                                })
                            number += 1
                        except OSError as error:
                            errors.append(f"{file_path.name}: {error}")

                    if changes:
                        record_action("Batch Rename", changes)
                        st.success(f"Renamed {len(changes)} file(s).")

                    if errors:
                        for error in errors:
                            st.warning(error)

                    if changes:
                        st.dataframe(changes, use_container_width=True)
        else:
            st.info("No files available to rename.")
    else:
        st.info("Enter a valid folder path in the sidebar.")


elif menu == "Activity Logs":
    st.subheader("Activity Logs")

    history = load_history()

    if history:
        for action_number, action in enumerate(reversed(history), start=1):
            with st.expander(
                f'{action_number}. {action["type"]} — {action["time"]}'
            ):
                st.dataframe(
                    action.get("changes", []),
                    use_container_width=True
                )
    else:
        st.info("No actions have been recorded yet.")


elif menu == "Undo Last Action":
    st.subheader("Undo Last Action")

    history = load_history()

    if not history:
        st.info("There are no recorded actions to undo.")
    else:
        last_action = history[-1]

        st.write(f'Last action: **{last_action["type"]}**')
        st.write(f'Time: {last_action["time"]}')

        st.warning(
            "Undo will attempt to restore files to their previous paths. "
            "It will not overwrite any existing file."
        )

        confirm_undo = st.checkbox("I want to undo this action.")

        if st.button("Undo Now", type="primary"):
            if not confirm_undo:
                st.warning("Please confirm before undoing.")
            else:
                changes = last_action.get("changes", [])
                successful = 0
                failed = []

                for change in reversed(changes):
                    source = Path(change["to"])
                    destination = Path(change["from"])

                    if move_backwards(source, destination):
                        successful += 1
                    else:
                        failed.append(str(source))

                if successful == len(changes):
                    history.pop()
                    save_history(history)
                    st.success(f"Undo completed: {successful} file(s) restored.")
                else:
                    st.warning(
                        f"Restored {successful} file(s). "
                        "Some files could not be restored."
                    )
                    for path in failed:
                        st.code(path)

                if successful:
                    st.info("Check the original folder to verify the result.")
