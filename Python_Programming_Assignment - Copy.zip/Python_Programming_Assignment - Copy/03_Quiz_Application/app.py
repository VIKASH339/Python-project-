
import streamlit as st
import pandas as pd
import os
import time

# Page settings
st.set_page_config(
    page_title="Quiz Application",
    page_icon="📝",
    layout="centered"
)

st.title("📝 Quiz Application")
st.write("Test your knowledge with this quiz!")

# Quiz settings
TOTAL_TIME = 120
CORRECT_MARKS = 4
WRONG_MARKS = -1

# Leaderboard file
LEADERBOARD_FILE = os.path.join(
    os.path.dirname(__file__), "leaderboard.csv"
)

# Quiz questions
QUESTIONS = [
    {
        "question": "1. Which language is used for Python programming?",
        "options": ["HTML", "Python", "CSS", "SQL"],
        "answer": "Python"
    },
    {
        "question": "2. Which data type stores whole numbers in Python?",
        "options": ["str", "float", "int", "list"],
        "answer": "int"
    },
    {
        "question": "3. Which symbol is used for comments in Python?",
        "options": ["//", "#", "/*", "$"],
        "answer": "#"
    },
    {
        "question": "4. Which function displays output in Python?",
        "options": ["input()", "show()", "print()", "display()"],
        "answer": "print()"
    },
    {
        "question": "5. Which data type stores True or False?",
        "options": ["int", "str", "bool", "list"],
        "answer": "bool"
    },
    {
        "question": "6. Which loop is used to iterate over a sequence?",
        "options": ["for", "switch", "case", "define"],
        "answer": "for"
    },
    {
        "question": "7. Which brackets are used to create a list?",
        "options": ["()", "{}", "[]", "<>"],
        "answer": "[]"
    },
    {
        "question": "8. Which keyword defines a function in Python?",
        "options": ["function", "def", "fun", "create"],
        "answer": "def"
    },
    {
        "question": "9. Which operator checks equality?",
        "options": ["=", "==", "!=", ":"],
        "answer": "=="
    },
    {
        "question": "10. Which keyword is used for a condition?",
        "options": ["if", "for", "print", "import"],
        "answer": "if"
    }
]

# Initialize session state
if "started" not in st.session_state:
    st.session_state.started = False

if "finished" not in st.session_state:
    st.session_state.finished = False

if "answers" not in st.session_state:
    st.session_state.answers = {}

if "current_question" not in st.session_state:
    st.session_state.current_question = 0

if "player_name" not in st.session_state:
    st.session_state.player_name = ""

if "start_time" not in st.session_state:
    st.session_state.start_time = 0.0

if "score" not in st.session_state:
    st.session_state.score = 0


# Save score to leaderboard
def save_score(name, score):
    new_row = pd.DataFrame([{
        "Player": name,
        "Score": score
    }])

    if os.path.exists(LEADERBOARD_FILE):
        old_data = pd.read_csv(LEADERBOARD_FILE)
        new_data = pd.concat(
            [old_data, new_row],
            ignore_index=True
        )
    else:
        new_data = new_row

    new_data.to_csv(LEADERBOARD_FILE, index=False)


# Calculate final score
def calculate_score():
    score = 0

    for index, question in enumerate(QUESTIONS):
        selected = st.session_state.answers.get(index)

        if selected is None:
            continue

        if selected == question["answer"]:
            score += CORRECT_MARKS
        else:
            score += WRONG_MARKS

    return score


# Finish quiz
def finish_quiz():
    if not st.session_state.finished:
        st.session_state.score = calculate_score()
        st.session_state.finished = True

        save_score(
            st.session_state.player_name,
            st.session_state.score
        )


# Start screen
if not st.session_state.started:
    st.subheader("Welcome!")

    name = st.text_input("Enter your name")

    st.info(
        "10 questions | 120 seconds | "
        "+4 for correct answers | -1 for wrong answers"
    )

    if st.button("Start Quiz", type="primary"):
        if not name.strip():
            st.warning("Please enter your name first.")
        else:
            st.session_state.player_name = name.strip()
            st.session_state.started = True
            st.session_state.start_time = time.time()
            st.session_state.answers = {}
            st.session_state.current_question = 0
            st.session_state.finished = False
            st.rerun()


# Quiz screen
elif st.session_state.started and not st.session_state.finished:

    # Timer refreshes every second
    @st.fragment(run_every="1s")
    def quiz_screen():
        elapsed = int(time.time() - st.session_state.start_time)
        remaining = max(0, TOTAL_TIME - elapsed)

        st.subheader(
            f"Player: {st.session_state.player_name}"
        )
        st.metric("Time Remaining", f"{remaining} seconds")

        if remaining <= 0:
            finish_quiz()
            st.rerun()
            return

        index = st.session_state.current_question
        question = QUESTIONS[index]

        st.progress((index + 1) / len(QUESTIONS))
        st.write(f"Question {index + 1} of {len(QUESTIONS)}")
        st.markdown(f"### {question['question']}")

        previous_answer = st.session_state.answers.get(index)

        selected = st.radio(
            "Choose one answer:",
            question["options"],
            index=(
                question["options"].index(previous_answer)
                if previous_answer in question["options"]
                else None
            ),
            key=f"answer_{index}"
        )

        col1, col2 = st.columns(2)

        with col1:
            if index > 0:
                if st.button("⬅ Previous"):
                    st.session_state.current_question -= 1
                    st.rerun()

        with col2:
            if index < len(QUESTIONS) - 1:
                if st.button("Next ➡", type="primary"):
                    if selected is not None:
                        st.session_state.answers[index] = selected

                    st.session_state.current_question += 1
                    st.rerun()
            else:
                if st.button("Submit Quiz", type="primary"):
                    if selected is not None:
                        st.session_state.answers[index] = selected

                    finish_quiz()
                    st.rerun()

    quiz_screen()


# Result screen
if st.session_state.finished:
    st.header("🎉 Quiz Completed!")

    score = st.session_state.score
    max_score = len(QUESTIONS) * CORRECT_MARKS

    st.write(f"**Player:** {st.session_state.player_name}")
    st.metric("Your Score", f"{score} / {max_score}")

    correct = sum(
        1 for i, q in enumerate(QUESTIONS)
        if st.session_state.answers.get(i) == q["answer"]
    )

    wrong = sum(
        1 for i, q in enumerate(QUESTIONS)
        if i in st.session_state.answers
        and st.session_state.answers[i] != q["answer"]
    )

    unanswered = len(QUESTIONS) - correct - wrong

    st.write(f"✅ Correct answers: {correct}")
    st.write(f"❌ Wrong answers: {wrong}")
    st.write(f"⏭️ Unanswered: {unanswered}")

    st.subheader("Answer Review")

    for i, q in enumerate(QUESTIONS):
        st.write(f"**{q['question']}**")
        st.write(
            f"Your answer: {st.session_state.answers.get(i, 'Not answered')}"
        )
        st.write(f"Correct answer: {q['answer']}")
        st.divider()

    if os.path.exists(LEADERBOARD_FILE):
        st.subheader("🏆 Leaderboard")
        leaderboard = pd.read_csv(LEADERBOARD_FILE)
        leaderboard = leaderboard.sort_values(
            "Score", ascending=False
        ).reset_index(drop=True)

        st.dataframe(leaderboard, use_container_width=True)

    if st.button("Play Again", type="primary"):
        st.session_state.started = False
        st.session_state.finished = False
        st.session_state.answers = {}
        st.session_state.current_question = 0
        st.session_state.player_name = ""
        st.session_state.start_time = 0.0
        st.session_state.score = 0
        st.rerun()
