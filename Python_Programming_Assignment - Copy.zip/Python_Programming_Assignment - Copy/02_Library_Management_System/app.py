
import streamlit as st
import csv
import os
from datetime import date, timedelta

FILE = "books.csv"
FINE_PER_DAY = 5

st.set_page_config(page_title="Library Management System", page_icon="📚")
st.title("📚 Library Management System")

def load_books():
    books = []
    if os.path.exists(FILE):
        with open(FILE, "r", newline="", encoding="utf-8") as f:
            books = list(csv.DictReader(f))
    return books

def save_books(books):
    fields = ["book_id", "title", "author", "status",
              "borrower", "issue_date", "due_date"]
    with open(FILE, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(books)

books = load_books()

menu = st.sidebar.selectbox(
    "Choose Option",
    ["Home", "Add Book", "View Books", "Search Book",
     "Issue Book", "Return Book", "Backup & Restore"]
)

if menu == "Home":
    st.subheader("Library Dashboard")
    total = len(books)
    issued = sum(b["status"] == "Issued" for b in books)
    available = total - issued

    c1, c2, c3 = st.columns(3)
    c1.metric("Total Books", total)
    c2.metric("Available", available)
    c3.metric("Issued", issued)

    st.info("Use the sidebar to manage library books.")

elif menu == "Add Book":
    st.subheader("Add New Book")

    with st.form("add_book_form"):
        book_id = st.text_input("Book ID")
        title = st.text_input("Book Title")
        author = st.text_input("Author Name")
        submitted = st.form_submit_button("Add Book")

    if submitted:
        if not book_id.strip() or not title.strip() or not author.strip():
            st.error("Please fill in all fields.")
        elif any(b["book_id"].lower() == book_id.strip().lower()
                 for b in books):
            st.error("This Book ID already exists.")
        else:
            books.append({
                "book_id": book_id.strip(),
                "title": title.strip(),
                "author": author.strip(),
                "status": "Available",
                "borrower": "",
                "issue_date": "",
                "due_date": ""
            })
            save_books(books)
            st.success("Book added successfully!")
            st.info("Your book has been saved in books.csv.")

elif menu == "View Books":
    st.subheader("All Books")

    if books:
        sort_by = st.selectbox("Sort by", ["Title", "Author", "Book ID"])
        key = {"Title": "title", "Author": "author",
               "Book ID": "book_id"}[sort_by]
        st.dataframe(sorted(books, key=lambda b: b[key].lower()),
                     use_container_width=True)
    else:
        st.info("No books found. Add a book first.")

elif menu == "Search Book":
    st.subheader("Search Books")
    query = st.text_input("Enter title or author")

    if query:
        results = [
            b for b in books
            if query.lower() in b["title"].lower()
            or query.lower() in b["author"].lower()
            or query.lower() in b["book_id"].lower()
        ]
        if results:
            st.dataframe(results, use_container_width=True)
        else:
            st.warning("No matching books found.")

elif menu == "Issue Book":
    st.subheader("Issue a Book")

    available_books = [b for b in books if b["status"] == "Available"]

    if not available_books:
        st.info("No books are currently available.")
    else:
        choices = {
            f'{b["book_id"]} - {b["title"]}': b["book_id"]
            for b in available_books
        }
        selected = st.selectbox("Select Book", list(choices.keys()))
        borrower = st.text_input("Student / Borrower Name")
        issue_day = st.date_input("Issue Date", value=date.today())
        due_day = st.date_input(
            "Due Date", value=date.today() + timedelta(days=14),
            min_value=issue_day
        )

        if st.button("Issue Book"):
            if not borrower.strip():
                st.error("Enter the borrower's name.")
            elif due_day < issue_day:
                st.error("Due date cannot be before issue date.")
            else:
                book_id = choices[selected]
                for b in books:
                    if b["book_id"] == book_id:
                        b["status"] = "Issued"
                        b["borrower"] = borrower.strip()
                        b["issue_date"] = issue_day.isoformat()
                        b["due_date"] = due_day.isoformat()
                        break
                save_books(books)
                st.success("Book issued successfully!")
                st.info("The book is now marked as Issued.")


elif menu == "Return Book":
    st.subheader("Return a Book")

    issued_books = [b for b in books if b["status"] == "Issued"]

    if not issued_books:
        st.info("No books are currently issued.")
    else:
        choices = {
            f'{b["book_id"]} - {b["title"]} ({b["borrower"]})':
            b["book_id"] for b in issued_books
        }

        selected = st.selectbox("Select Issued Book", list(choices.keys()))
        return_day = st.date_input("Return Date", value=date.today())

        if st.button("Return Book"):
            book_id = choices[selected]

            for b in books:
                if b["book_id"] == book_id:
                    due_day = date.fromisoformat(b["due_date"])
                    late_days = max(0, (return_day - due_day).days)
                    fine = late_days * FINE_PER_DAY

                    b["status"] = "Available"
                    b["borrower"] = ""
                    b["issue_date"] = ""
                    b["due_date"] = ""
                    break

            save_books(books)

            st.success("Book returned successfully!")
            st.write(f"Late days: {late_days}")
            st.write(f"Fine: ₹{fine}")

elif menu == "Backup & Restore":
    st.subheader("Backup and Restore")

    if books:
        backup_data = "book_id,title,author,status,borrower,issue_date,due_date\n"
        for b in books:
            values = [
                b["book_id"], b["title"], b["author"], b["status"],
                b["borrower"], b["issue_date"], b["due_date"]
            ]
            import io
            output = io.StringIO()
            writer = csv.writer(output)
            writer.writerow(values)
            backup_data += output.getvalue()

        st.download_button(
            "Download Books Backup",
            data=backup_data,
            file_name="books_backup.csv",
            mime="text/csv"
        )

    uploaded = st.file_uploader("Restore from CSV backup", type=["csv"])

    if uploaded is not None and st.button("Restore Backup"):
        try:
            restored = list(csv.DictReader(
                uploaded.getvalue().decode("utf-8-sig").splitlines()
            ))
            required = {"book_id", "title", "author", "status",
                        "borrower", "issue_date", "due_date"}

            if not required.issubset(restored[0].keys()):
                st.error("Backup file has an invalid format.")
            elif any(b["status"] not in ["Available", "Issued"]
                     for b in restored):
                st.error("Backup contains an invalid book status.")
            elif len({b["book_id"] for b in restored}) != len(restored):
                st.error("Backup contains duplicate Book IDs.")
            else:
                save_books(restored)
                st.success("Backup restored successfully!")
                st.rerun()
        except (ValueError, UnicodeDecodeError, IndexError, csv.Error):
            st.error("Could not restore this file. Check the CSV format.")