
import streamlit as st
import pandas as pd
import numpy as np
import os

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import TruncatedSVD
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error


# ---------------- PAGE SETTINGS ----------------

st.set_page_config(
    page_title="Movie Recommender System",
    page_icon="🎬",
    layout="wide"
)

st.title("🎬 Movie Recommender System")
st.write("Discover movies based on your interests and user ratings.")


# ---------------- SAMPLE DATA ----------------

def create_sample_data():
    movies = pd.DataFrame({
        "movieId": list(range(1, 16)),
        "title": [
            "The Space Journey", "Galaxy Wars", "Future Robot",
            "Love Forever", "Romantic Days", "Wedding Story",
            "Mystery House", "Hidden Clues", "Crime Detective",
            "Funny Friends", "Comedy Night", "Crazy Vacation",
            "Magic Kingdom", "Dragon Adventure", "Hero Returns"
        ],
        "genres": [
            "Sci-Fi Adventure", "Sci-Fi Action", "Sci-Fi Adventure",
            "Romance Drama", "Romance Comedy", "Romance Drama",
            "Mystery Thriller", "Mystery Crime", "Crime Thriller",
            "Comedy Friends", "Comedy", "Comedy Adventure",
            "Fantasy Adventure", "Fantasy Adventure", "Action Adventure"
        ]
    })

    ratings_data = [
        (1, 1, 5), (1, 2, 4), (1, 3, 5), (1, 4, 2),
        (1, 7, 3), (1, 13, 4), (1, 14, 5),
        (2, 4, 5), (2, 5, 5), (2, 6, 4), (2, 10, 4),
        (2, 11, 3), (2, 1, 2),
        (3, 7, 5), (3, 8, 5), (3, 9, 4), (3, 2, 3),
        (3, 15, 4), (3, 4, 2),
        (4, 10, 5), (4, 11, 4), (4, 12, 5), (4, 5, 3),
        (4, 13, 3),
        (5, 1, 4), (5, 2, 5), (5, 3, 4), (5, 14, 5),
        (5, 15, 4), (5, 6, 2),
        (6, 4, 4), (6, 5, 5), (6, 6, 5), (6, 10, 3),
        (6, 12, 2),
        (7, 7, 4), (7, 8, 5), (7, 9, 5), (7, 15, 4),
        (7, 3, 3),
        (8, 10, 4), (8, 11, 5), (8, 12, 4), (8, 13, 3),
        (8, 4, 2),
        (9, 1, 5), (9, 3, 4), (9, 13, 5), (9, 14, 4),
        (9, 2, 5),
        (10, 4, 5), (10, 5, 4), (10, 6, 5), (10, 11, 4),
        (10, 12, 3)
    ]

    ratings = pd.DataFrame(
        ratings_data,
        columns=["userId", "movieId", "rating"]
    )

    return movies, ratings


# ---------------- LOAD DATA ----------------

st.sidebar.header("Dataset")

st.sidebar.write(
    "Use the built-in demo dataset or upload your own CSV files."
)

movies_file = st.sidebar.file_uploader(
    "Upload movies.csv (optional)",
    type=["csv"]
)

ratings_file = st.sidebar.file_uploader(
    "Upload ratings.csv (optional)",
    type=["csv"]
)

if (movies_file is None) != (ratings_file is None):
    st.error("Upload both CSV files, or use the built-in demo dataset.")
    st.stop()

if movies_file is not None and ratings_file is not None:
    movies = pd.read_csv(movies_file)
    ratings = pd.read_csv(ratings_file)

    if not {"movieId", "title"}.issubset(movies.columns):
        st.error("movies.csv must contain movieId and title columns.")
        st.stop()

    if not {"userId", "movieId", "rating"}.issubset(ratings.columns):
        st.error("ratings.csv must contain userId, movieId and rating.")
        st.stop()

    if "genres" not in movies.columns:
        movies["genres"] = ""

    movies["genres"] = movies["genres"].fillna("").astype(str)

else:
    movies, ratings = create_sample_data()


# ---------------- CLEAN DATA ----------------

movies = movies.dropna(subset=["movieId", "title"]).copy()
ratings = ratings.dropna(
    subset=["userId", "movieId", "rating"]
).copy()

movies["movieId"] = pd.to_numeric(
    movies["movieId"], errors="coerce"
)
ratings["movieId"] = pd.to_numeric(
    ratings["movieId"], errors="coerce"
)
ratings["rating"] = pd.to_numeric(
    ratings["rating"], errors="coerce"
)

movies = movies.dropna(subset=["movieId"])
ratings = ratings.dropna(
    subset=["userId", "movieId", "rating"]
)

movies["movieId"] = movies["movieId"].astype(int)
ratings["movieId"] = ratings["movieId"].astype(int)

movies = movies.drop_duplicates(subset=["movieId"])
ratings = ratings[
    ratings["movieId"].isin(movies["movieId"])
].copy()

if movies.empty or ratings.empty:
    st.error("The dataset has no usable movies or ratings.")
    st.stop()


# ---------------- SIDEBAR INFORMATION ----------------

st.sidebar.success("Dataset loaded successfully!")

st.sidebar.metric("Total Movies", len(movies))
st.sidebar.metric("Total Ratings", len(ratings))
st.sidebar.metric("Total Users", ratings["userId"].nunique())


# ---------------- CONTENT-BASED FILTERING ----------------

st.header("1. Content-Based Recommendations")

st.write(
    "This method recommends movies with genres similar "
    "to the movie you select."
)

movies["content"] = (
    movies["title"].astype(str) + " " +
    movies["genres"].astype(str)
)

tfidf = TfidfVectorizer(stop_words="english")
tfidf_matrix = tfidf.fit_transform(movies["content"])

content_similarity = cosine_similarity(tfidf_matrix)

movie_titles = movies["title"].tolist()

selected_movie = st.selectbox(
    "Select a movie you like",
    movie_titles,
    key="content_movie"
)

number_recommendations = st.slider(
    "Number of recommendations",
    min_value=1,
    max_value=10,
    value=5
)

if st.button("Recommend Similar Movies"):
    movie_index = movies.index[
        movies["title"] == selected_movie
    ][0]

    scores = list(enumerate(content_similarity[movie_index]))
    scores = sorted(scores, key=lambda x: x[1], reverse=True)

    st.subheader("Recommended Movies")

    shown = 0

    for index, similarity_score in scores:
        if index == movie_index:
            continue

        row = movies.iloc[index]

        st.write(
            f"🎬 **{row['title']}** — "
            f"Genres: {row['genres']}"
        )

        shown += 1

        if shown >= number_recommendations:
            break


# ---------------- COLLABORATIVE FILTERING ----------------

st.divider()
st.header("2. Collaborative Filtering")

st.write(
    "This method uses ratings from users with similar "
    "movie preferences."
)

user_ids = sorted(ratings["userId"].unique(), key=str)

selected_user = st.selectbox(
    "Select a user",
    user_ids,
    key="collab_user"
)

rating_matrix = ratings.pivot_table(
    index="userId",
    columns="movieId",
    values="rating"
)

if len(user_ids) >= 2:
    user_similarity = cosine_similarity(
        rating_matrix.fillna(0)
    )

    user_similarity_df = pd.DataFrame(
        user_similarity,
        index=rating_matrix.index,
        columns=rating_matrix.index
    )

    if st.button("Recommend Movies for User"):
        rated_movies = ratings[
            ratings["userId"] == selected_user
        ]["movieId"].tolist()

        similar_users = user_similarity_df[
            selected_user
        ].drop(index=selected_user).sort_values(
            ascending=False
        )

        candidate_scores = {}

        for movie_id in rating_matrix.columns:
            if movie_id in rated_movies:
                continue

            numerator = 0.0
            denominator = 0.0

            for other_user, similarity in similar_users.items():
                other_rating = rating_matrix.loc[
                    other_user, movie_id
                ]

                if pd.notna(other_rating) and similarity > 0:
                    numerator += similarity * other_rating
                    denominator += similarity

            if denominator > 0:
                candidate_scores[movie_id] = (
                    numerator / denominator
                )

        if candidate_scores:
            recommendations = sorted(
                candidate_scores.items(),
                key=lambda x: x[1],
                reverse=True
            )[:5]

            for movie_id, predicted_rating in recommendations:
                title = movies.loc[
                    movies["movieId"] == movie_id, "title"
                ].iloc[0]

                st.write(
                    f"🎬 **{title}** — "
                    f"Predicted rating: {predicted_rating:.2f}/5"
                )
        else:
            st.info(
                "Not enough similar-user ratings. "
                "Try another user or a larger dataset."
            )
else:
    st.info("Collaborative filtering needs at least two users.")


# ---------------- SVD MODEL ----------------

st.divider()
st.header("3. SVD Recommendation Model")

st.write(
    "SVD reduces the user-movie rating matrix into "
    "a smaller set of latent features."
)

if (
    rating_matrix.shape[0] >= 2
    and rating_matrix.shape[1] >= 2
    and min(rating_matrix.shape) >= 2
):
    svd_components = min(
        5,
        rating_matrix.shape[0] - 1,
        rating_matrix.shape[1] - 1
    )

    filled_matrix = rating_matrix.fillna(0)

    svd_model = TruncatedSVD(
        n_components=svd_components,
        random_state=42
    )

    latent_users = svd_model.fit_transform(filled_matrix)
    reconstructed = (
        latent_users @ svd_model.components_
    )

    predicted_matrix = pd.DataFrame(
        reconstructed,
        index=rating_matrix.index,
        columns=rating_matrix.columns
    )

    svd_user = st.selectbox(
        "Select user for SVD recommendations",
        user_ids,
        key="svd_user"
    )

    if st.button("Get SVD Recommendations"):
        already_rated = ratings[
            ratings["userId"] == svd_user
        ]["movieId"].tolist()

        user_predictions = predicted_matrix.loc[svd_user]
        user_predictions = user_predictions.drop(
            labels=already_rated,
            errors="ignore"
        ).sort_values(ascending=False).head(5)

        if user_predictions.empty:
            st.info("No unrated movies available for this user.")
        else:
            for movie_id, predicted_rating in user_predictions.items():
                title_row = movies[
                    movies["movieId"] == movie_id
                ]

                if not title_row.empty:
                    title = title_row.iloc[0]["title"]

                    st.write(
                        f"🎬 **{title}** — "
                        f"Model score: {predicted_rating:.2f}"
                    )
else:
    st.info(
        "SVD needs at least two users and two movies "
        "with valid rating data."
    )


# ---------------- MODEL EVALUATION ----------------

st.divider()
st.header("4. Model Evaluation: RMSE and MAE")

st.write(
    "We split the ratings into training and testing sets. "
    "The model learns from training data and is evaluated "
    "on held-out ratings."
)

if len(ratings) >= 10 and min(rating_matrix.shape) >= 2:
    if st.button("Evaluate SVD Model"):
        train_data, test_data = train_test_split(
            ratings,
            test_size=0.2,
            random_state=42
        )

        train_matrix = train_data.pivot_table(
            index="userId",
            columns="movieId",
            values="rating"
        )

        eval_components = min(
            5,
            train_matrix.shape[0] - 1,
            train_matrix.shape[1] - 1
        )

        if eval_components < 1:
            st.warning(
                "Dataset is too small to evaluate SVD. "
                "Try a larger ratings dataset."
            )
        else:
            eval_model = TruncatedSVD(
                n_components=eval_components,
                random_state=42
            )

            train_filled = train_matrix.fillna(0)
            user_factors = eval_model.fit_transform(train_filled)
            reconstructed_train = (
                user_factors @ eval_model.components_
            )

            prediction_matrix = pd.DataFrame(
                reconstructed_train,
                index=train_matrix.index,
                columns=train_matrix.columns
            )

            global_mean = train_data["rating"].mean()
            actual = []
            predicted = []

            for row in test_data.itertuples(index=False):
                if (
                    row.userId in prediction_matrix.index
                    and row.movieId in prediction_matrix.columns
                ):
                    pred = prediction_matrix.loc[
                        row.userId, row.movieId
                    ]
                else:
                    pred = global_mean

                # Ratings are normally on a 0-5 scale
                pred = float(np.clip(pred, 0, 5))

                actual.append(float(row.rating))
                predicted.append(pred)

            rmse = np.sqrt(
                mean_squared_error(actual, predicted)
            )
            mae = mean_absolute_error(actual, predicted)

            col1, col2 = st.columns(2)

            col1.metric("RMSE", f"{rmse:.3f}")
            col2.metric("MAE", f"{mae:.3f}")

            st.caption(
                "Lower values generally indicate smaller prediction errors. "
                "Results depend on the dataset and split."
            )
else:
    st.info(
        "Evaluation needs at least 10 ratings and multiple users "
        "and movies. Upload a larger dataset for more reliable results."
    )


# ---------------- COLD START ----------------

st.divider()
st.header("5. Cold Start Solution")

st.write(
    "Cold start happens when a new user or movie has little "
    "or no rating history."
)

st.subheader("New User Recommendations")

st.write("Choose a genre to get popular movies from that genre.")

all_genres = sorted({
    genre.strip()
    for genres in movies["genres"].fillna("")
    for genre in str(genres).replace("|", " ").split()
    if genre.strip()
})

if all_genres:
    chosen_genre = st.selectbox(
        "Choose your favourite genre",
        all_genres
    )

    average_ratings = ratings.groupby(
        "movieId"
    )["rating"].agg(["mean", "count"]).reset_index()

    popular_movies = movies.merge(
        average_ratings,
        on="movieId",
        how="left"
    )

    popular_movies["mean"] = popular_movies["mean"].fillna(0)
    popular_movies["count"] = popular_movies["count"].fillna(0)

    if st.button("Find Movies for New User"):
        genre_matches = popular_movies[
            popular_movies["genres"].str.contains(
                chosen_genre, case=False, regex=False
            )
        ]

        genre_matches = genre_matches.sort_values(
            ["mean", "count"],
            ascending=False
        )

        if genre_matches.empty:
            st.info("No movies found for this genre.")
        else:
            for row in genre_matches.head(5).itertuples():
                st.write(
                    f"🎬 **{row.title}** — "
                    f"Average rating: {row.mean:.2f}/5"
                )
else:
    st.info("No genre information is available in this dataset.")


# ---------------- FOOTER ----------------

st.divider()
st.caption(
    "Movie Recommender System | Python, Streamlit, "
    "Pandas and Scikit-learn"
)
