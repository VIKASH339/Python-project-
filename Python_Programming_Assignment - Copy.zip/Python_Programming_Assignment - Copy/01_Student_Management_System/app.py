
import streamlit as st
import csv
import os

FILE = "students.csv"

# Page settings
st.set_page_config(
    page_title="Student Management System",
    page_icon="🎓",
    layout="wide"
)


# Load student records
def load_students():
    if not os.path.exists(FILE):
        return []

    with open(FILE, "r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        return list(reader)


# Save all student records
def save_students(students):
    with open(FILE, "w", newline="", encoding="utf-8") as file:
        fieldnames = ["Name", "Roll Number", "Marks"]
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(students)


# Add a student
def add_student(name, roll_no, marks):
    students = load_students()

    for student in students:
        if student["Roll Number"] == roll_no:
            return False

    students.append({
        "Name": name,
        "Roll Number": roll_no,
        "Marks": str(marks)
    })

    save_students(students)
    return True


# Application heading
st.title("🎓 Student Management System")
st.caption("Manage student records easily")

# Sidebar menu
st.sidebar.title("📋 Menu")

option = st.sidebar.selectbox(
    "Choose an option",
    [
        "Home",
        "Add Student",
        "View Students",
        "Search Student",
        "Update Student",
        "Delete Student",
        "Reports"
    ]
)


# HOME
if option == "Home":
    st.header("Welcome to Student Management System")

    students = load_students()

    col1, col2, col3 = st.columns(3)

    col1.metric("Total Students", len(students))

    if students:
        marks_list = [float(s["Marks"]) for s in students]
        col2.metric("Average Marks", f"{sum(marks_list) / len(marks_list):.2f}")
        col3.metric("Highest Marks", f"{max(marks_list):.2f}")
    else:
        col2.metric("Average Marks", "0")
        col3.metric("Highest Marks", "0")

    st.info("Select an option from the sidebar to get started.")


# ADD STUDENT
elif option == "Add Student":
    st.header("➕ Add New Student")

    with st.form("add_student_form"):
        name = st.text_input("Student Name")
        roll_no = st.text_input("Roll Number")
        marks = st.number_input(
            "Marks",
            min_value=0.0,
            max_value=100.0,
            step=1.0
        )

        submitted = st.form_submit_button("Add Student")

    if submitted:
        name = name.strip()
        roll_no = roll_no.strip()

        if not name or not roll_no:
            st.error("Please enter both name and roll number.")
        else:
            try:
                if add_student(name, roll_no, marks):
                    st.success("Student added successfully!")
                else:
                    st.error("This roll number already exists.")
            except OSError:
                st.error("Unable to save data. Check folder permissions.")


# VIEW STUDENTS
elif option == "View Students":
    st.header("📚 All Student Records")

    students = load_students()

    if students:
        sort_by = st.selectbox(
            "Sort records by",
            ["Name", "Marks"]
        )

        if sort_by == "Name":
            students.sort(key=lambda s: s["Name"].lower())
        else:
            students.sort(key=lambda s: float(s["Marks"]), reverse=True)

        st.dataframe(students, use_container_width=True)
        st.caption(f"Total records: {len(students)}")
    else:
        st.info("No student records available.")


# SEARCH STUDENT
elif option == "Search Student":
    st.header("🔍 Search Student")

    roll_no = st.text_input("Enter Roll Number")

    if st.button("Search"):
        students = load_students()

        result = [
            s for s in students
            if s["Roll Number"] == roll_no.strip()
        ]

        if result:
            st.success("Student found!")
            st.dataframe(result, use_container_width=True)
        else:
            st.warning("Student not found.")


# UPDATE STUDENT
elif option == "Update Student":
    st.header("✏️ Update Student")

    roll_no = st.text_input("Enter Roll Number")

    students = load_students()

    student = next(
        (s for s in students if s["Roll Number"] == roll_no.strip()),
        None
    ) if roll_no.strip() else None

    if student:
        st.success(f"Student found: {student['Name']}")

        with st.form("update_student_form"):
            new_name = st.text_input(
                "Student Name",
                value=student["Name"]
            )

            new_marks = st.number_input(
                "Marks",
                min_value=0.0,
                max_value=100.0,
                value=float(student["Marks"]),
                step=1.0
            )

            update_button = st.form_submit_button("Save Changes")

        if update_button:
            new_name = new_name.strip()

            if not new_name:
                st.error("Student name cannot be empty.")
            else:
                for s in students:
                    if s["Roll Number"] == roll_no.strip():
                        s["Name"] = new_name
                        s["Marks"] = str(new_marks)

                save_students(students)
                st.success("Student updated successfully!")
                st.rerun()

    elif roll_no.strip():
        st.warning("Student not found.")


# DELETE STUDENT
elif option == "Delete Student":
    st.header("🗑️ Delete Student")

    roll_no = st.text_input("Enter Roll Number to Delete")

    if st.button("Find Student"):
        students = load_students()

        student = next(
            (s for s in students if s["Roll Number"] == roll_no.strip()),
            None
        )

        if student:
            st.session_state["delete_roll_no"] = student["Roll Number"]
            st.session_state["delete_name"] = student["Name"]
        else:
            st.session_state.pop("delete_roll_no", None)
            st.session_state.pop("delete_name", None)
            st.warning("Student not found.")

    if "delete_roll_no" in st.session_state:
        st.warning(
            f"Confirm deletion of {st.session_state['delete_name']} "
            f"(Roll No: {st.session_state['delete_roll_no']})"
        )

        confirm = st.checkbox("I confirm that I want to delete this record")

        if st.button("Confirm Delete", type="primary"):
            if not confirm:
                st.error("Please confirm before deleting.")
            else:
                target_roll = st.session_state["delete_roll_no"]
                students = load_students()

                remaining = [
                    s for s in students
                    if s["Roll Number"] != target_roll
                ]

                if len(remaining) < len(students):
                    save_students(remaining)
                    st.session_state.pop("delete_roll_no", None)
                    st.session_state.pop("delete_name", None)
                    st.success("Student deleted successfully!")
                    st.rerun()
                else:
                    st.error("Student record was not found.")


# REPORTS
elif option == "Reports":
    st.header("📊 Student Reports")

    students = load_students()

    if students:
        marks_list = [float(s["Marks"]) for s in students]

        average = sum(marks_list) / len(marks_list)
        highest = max(marks_list)

        toppers = [
            s for s in students
            if float(s["Marks"]) == highest
        ]

        col1, col2, col3 = st.columns(3)
        col1.metric("Total Students", len(students))
        col2.metric("Average Marks", f"{average:.2f}")
        col3.metric("Highest Marks", f"{highest:.2f}")

        st.subheader("🏆 Topper(s)")
        st.dataframe(toppers, use_container_width=True)

    else:
        st.info("Add student records to generate reports.")